THIS IS A FREE Full script Not a Sample ,You can Use It in real Projects
in this tutorial you will learn :
1- how to save your location (marker) dynamically in database using PHP MYSQL
2-How to show hide markers on the map
3- How to Save data from google info window with php
4- How to Dynamically add marker to Google Map
5- How to Load Multiple Markers on Google Maps JS API v3 
6- How to Remove Selected Marker Only with right click by using uniqueid
7- How to save checkbox state inside google map infowindow
8- How to set animation google maps marker
9- How dynamically change the marker icon after load

 the tutorial link https://youtu.be/q2VV3-yWupU
 the blog link http://webeasystep.com/